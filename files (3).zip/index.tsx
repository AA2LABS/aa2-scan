import { supabase } from '../../lib/supabase';
import Anthropic from '@anthropic-ai/sdk';
import { CameraView, useCameraPermissions } from 'expo-camera';
import React, { useRef, useState, useEffect } from 'react';
import {
  ActivityIndicator, Alert,
  Animated,
  FlatList, Modal,
  Platform,
  SafeAreaView,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
  useWindowDimensions,
  useColorScheme,
  Image,
} from 'react-native';

// ─── BREAKPOINT ───────────────────────────────────────────────────────────────
const FOLD_BREAKPOINT = 600;

// ─── ACCENT COLORS ───────────────────────────────────────────────────────────
const ACCENT = {
  electricBlue: '#4a9eff',
  teal:         '#2ecfb3',
  orange:       '#f5922a',
  gold:         '#c9a84c',
  purple:       '#b06abf',
  red:          '#e05252',
  allClear:     '#2ecfb3',
  headsUp:      '#c9a84c',
  payAttention: '#e05252',
};

// ─── THEMES ──────────────────────────────────────────────────────────────────
const DARK = {
  bg:        '#03050a',
  card:      'rgba(255,255,255,0.06)',
  border:    'rgba(255,255,255,0.11)',
  text:      '#ffffff',
  textMuted: 'rgba(255,255,255,0.65)',
  inputBg:   'rgba(255,255,255,0.04)',
  modalBg:   '#080c12',
  railBg:    '#08090d',
};

const LIGHT = {
  bg:        '#FAF7F2',
  card:      'rgba(0,0,0,0.04)',
  border:    'rgba(0,0,0,0.12)',
  text:      '#03050a',
  textMuted: '#6b5d4f',
  inputBg:   '#ffffff',
  modalBg:   '#f0ece6',
  railBg:    '#ede9e2',
};

const anthropic = new Anthropic({
  apiKey: process.env.EXPO_PUBLIC_ANTHROPIC_API_KEY,
  dangerouslyAllowBrowser: true,
});

const TABS = [
  { id: 'scan',       label: 'SCAN',         icon: '⚡',  color: ACCENT.gold         },
  { id: 'produce',    label: 'PRODUCE',       icon: '🌿',  color: ACCENT.teal         },
  { id: 'meat',       label: 'MEAT',          icon: '🥩',  color: ACCENT.red          },
  { id: 'care',       label: 'PERSONAL CARE', icon: '🧴',  color: ACCENT.purple       },
  { id: 'grownfolks', label: 'GROWN FOLKS',   icon: '🍷',  color: ACCENT.gold         },
  { id: 'species',    label: 'SPECIES',       icon: '🐾',  color: ACCENT.electricBlue },
];

const SPECIES_SUBS = [
  { id: 'k9',    label: 'K9 / PET',     icon: '🐕', color: ACCENT.electricBlue },
  { id: 'horse', label: 'EQUESTRIAN',   icon: '🐴', color: ACCENT.gold         },
  { id: 'agri',  label: 'AGRICULTURAL', icon: '🌾', color: ACCENT.teal         },
];

// ─── TAB HERO IMAGES ─────────────────────────────────────────────────────────
const TAB_IMAGES: Record<string, any> = {
  scan:       null,
  produce:    require('../../assets/images/tab-produce.png'),
  meat:       require('../../assets/images/tab-meat.png'),
  care:       require('../../assets/images/tab-care.png'),
  grownfolks: require('../../assets/images/tab-grownfolks.png'),
  k9:         require('../../assets/images/tab-k9.png'),
  horse:      require('../../assets/images/tab-horse.jpg'),
  agri:       require('../../assets/images/tab-agri.png'),
};

function buildSystemPrompt(tab: string, speciesSub?: string): string {
  const base = `You are The Equalizer — AA2's immune system and first line of truth. Backed by 9 databases: Open Food Facts, USDA FoodData Central, OpenFDA Food Recalls, OpenFDA Cosmetics/Animal & Veterinary, Open Beauty Facts/Open Pet Food Facts, PubChem NIH, EWG, ASPCA Animal Poison Control, EU CosIng/CA Safe Cosmetics/WHO FAO Codex.

PERSONALITY DOCTRINE: First person only. Direct, calm, factual. Never alarmist. NEVER use Heimdall, Kybalion, Denzel, Logic, or any mythological reference. Permanently banned.

Return ONLY valid JSON — no markdown, no backticks, no preamble.`;

  const schema = `{
  "verdict": "ALL CLEAR" | "HEADS UP" | "PAY ATTENTION",
  "verdictReason": "one sentence",
  "productName": "string",
  "keyFindings": ["string", "string", "string"],
  "databasesHit": ["string"],
  "equalizerVoice": "string — first person, calm, factual.",
  "chefNote": "string — REQUIRED. Exactly 3 numbered suggestions. Never null.",
  "actRightDollars": "string — REQUIRED. Exact savings. End with: That amount goes directly into your AA2 Vault as Act Right Dollars.",
  "recallAlert": "string or null",
  "alternatives": ["string"]
}`;

  if (tab === 'scan')       return `${base}\n\nPACKAGED / CANNED / BARCODED GOODS. Cross-reference all 9 databases. Flag additives, allergens, recall status. Translate chemical names.\n\nReturn:\n${schema}`;
  if (tab === 'produce')    return `${base}\n\nFRESH PRODUCE. Assess pesticide residue (EWG Dirty Dozen/Clean 15), ripeness, origin, nutrient density.\n\nReturn:\n${schema}`;
  if (tab === 'meat')       return `${base}\n\nMEAT — CO2/MAP TRUTH DOCTRINE. CO2/MAP keeps meat bright red after degradation. Trust nose and date. Assess freshness, antibiotic/hormone use.\n\nReturn:\n${schema}`;
  if (tab === 'care')       return `${base}\n\nPERSONAL CARE — SKIN INGESTION DOCTRINE. Skin absorbs everything. Cross-reference EWG, EU CosIng, CA Safe Cosmetics, OpenFDA. Flag endocrine disruptors, carcinogens, neurotoxins.\n\nReturn:\n${schema}`;
  if (tab === 'grownfolks') return `${base}\n\nGROWN FOLKS — Wine · Spirits · Beer. Sommelier speaks. Assess sulfites, tannins, additives, histamine. Pair red wine with cuts, port, whiskey, beer with dishes.\n\nReturn:\n${schema}`;
  if (tab === 'species') {
    const m: Record<string, string> = {
      k9:    `K9 / PET — ASPCA primary. Flag xylitol, grapes/raisins, onion family, macadamia, chocolate, artificial sweeteners, mycotoxins.`,
      horse: `EQUESTRIAN — FEI prohibited substances primary. Check equine supplement safety, mycotoxins, competition readiness.`,
      agri:  `AGRICULTURAL — USDA feed safety primary. Check mycotoxins, heavy metals, antibiotic residues, growth hormones.`,
    };
    return `${base}\n\n${m[speciesSub || 'k9']}\n\nReturn:\n${schema}`;
  }
  return base;
}

type ScanRecord = { id: string; timestamp: string; tab: string; query: string; verdict: string; productName: string; };

export default function ScannerScreen() {
  const { width } = useWindowDimensions();
  const isFold = width >= FOLD_BREAKPOINT;

  // ── NATIVE useColorScheme from react-native directly ──────────────────────
  const systemScheme = useColorScheme();
  const isDark = systemScheme !== 'light';
  const T = isDark ? DARK : LIGHT;

  const [permission, requestPermission] = useCameraPermissions();
  const [activeTab, setActiveTab] = useState('scan');
  const [speciesSub, setSpeciesSub] = useState('k9');
  const [cameraMode, setCameraMode] = useState(false);
  const [manualInput, setManualInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<any>(null);
  const [showBeAware, setShowBeAware] = useState(false);
  const [history, setHistory] = useState<ScanRecord[]>([]);
  const [historyVisible, setHistoryVisible] = useState(false);
  const [barcodeReady, setBarcodeReady] = useState(false);
  const scannedRef = useRef(false);
  const lastBarcodeRef = useRef<string | null>(null);

  // ── BE AWARE animation ────────────────────────────────────────────────────
  const beAwareOpacity = useRef(new Animated.Value(0)).current;
  const beAwareScale   = useRef(new Animated.Value(0.8)).current;

  const triggerBeAware = (onDone: () => void) => {
    setShowBeAware(true);
    beAwareOpacity.setValue(0);
    beAwareScale.setValue(0.8);
    Animated.sequence([
      Animated.parallel([
        Animated.timing(beAwareOpacity, { toValue: 1, duration: 250, useNativeDriver: true }),
        Animated.spring(beAwareScale,   { toValue: 1.05, useNativeDriver: true }),
      ]),
      Animated.delay(800),
      Animated.timing(beAwareOpacity, { toValue: 0, duration: 300, useNativeDriver: true }),
    ]).start(() => {
      setShowBeAware(false);
      onDone();
    });
  };

  const currentTab = TABS.find(t => t.id === activeTab)!;
  const accentColor = activeTab === 'species'
    ? SPECIES_SUBS.find(s => s.id === speciesSub)?.color || ACCENT.electricBlue
    : currentTab.color;

  const handleBarcodeScanned = ({ data }: { data: string }) => {
    if (loading) return;
    lastBarcodeRef.current = data;
    setBarcodeReady(true);
  };

  const handleManualSubmit = async () => {
    if (!manualInput.trim()) { Alert.alert('Enter Something', 'Type a product name or barcode.'); return; }
    await runAnalysis(manualInput.trim());
    setManualInput('');
  };

  const lookupBarcode = async (barcode: string): Promise<string> => {
    try {
      const res = await fetch(`https://world.openfoodfacts.org/api/v0/product/${barcode}.json`, { headers: { 'User-Agent': 'AA2-Scanner/1.0' } });
      const data = await res.json();
      if (data.status !== 1 || !data.product) return `Barcode: ${barcode}. Not found in Open Food Facts. Infer from training and return full verdict JSON.`;
      const p = data.product;
      return [
        `REAL PRODUCT DATA FROM OPEN FOOD FACTS:`,
        `PRODUCT: ${p.product_name || 'Unknown'}${p.brands ? ' by ' + p.brands : ''}`,
        `BARCODE: ${barcode}`,
        `INGREDIENTS: ${p.ingredients_text_en || p.ingredients_text || 'Not listed'}`,
        `ADDITIVES: ${p.additives_tags?.map((a: string) => a.replace('en:', '')).join(', ') || 'none'}`,
        `ALLERGENS: ${p.allergens_tags?.join(', ') || 'none listed'}`,
        p.nova_group     ? `NOVA Group: ${p.nova_group}` : '',
        p.nutriscore_grade ? `Nutri-Score: ${p.nutriscore_grade.toUpperCase()}` : '',
        `Analyze using all 9 databases and return verdict JSON.`,
      ].filter(Boolean).join('\n');
    } catch { return `Barcode: ${barcode}. Lookup failed.`; }
  };

  const runAnalysis = async (query: string) => {
    setLoading(true);
    setResult(null);
    const effectiveSub = activeTab === 'species' ? speciesSub : undefined;
    try {
      const isBarcode = activeTab === 'scan' && /^\d{6,14}$/.test(query.trim());
      let content = isBarcode
        ? `Barcode: ${query.trim()}. Analyze and return verdict JSON.`
        : activeTab === 'species'
        ? `${SPECIES_SUBS.find(s => s.id === speciesSub)?.label} — item: ${query}. Analyze and return verdict JSON.`
        : `Item: ${query}. Analyze and return verdict JSON.`;
      if (isBarcode) {
        const bd = await Promise.race([lookupBarcode(query.trim()), new Promise<null>(r => setTimeout(() => r(null), 2000))]);
        if (bd) content = bd;
      }
      const response = await anthropic.messages.create({
        model: 'claude-sonnet-4-20250514', max_tokens: 1000,
        system: buildSystemPrompt(activeTab, effectiveSub),
        messages: [{ role: 'user', content }],
      });
      const raw = (response.content[0] as any).text || '';
      const parsed = JSON.parse(raw.replace(/```json|```/g, '').trim());

      // ── Trigger BE AWARE glow, then show result ───────────────────────────
      setLoading(false);
      triggerBeAware(() => {
        setResult(parsed);
      });

      await saveToSupabase(parsed, query);
      setHistory(prev => [{
        id: Date.now().toString(), timestamp: new Date().toLocaleString(),
        tab: activeTab === 'species' ? `SPECIES · ${speciesSub.toUpperCase()}` : currentTab.label,
        query, verdict: parsed.verdict, productName: parsed.productName || query,
      }, ...prev].slice(0, 50));
    } catch {
      setLoading(false);
      Alert.alert('Scan Error', 'The Equalizer could not complete the analysis. Try again.');
    } finally {
      scannedRef.current = false;
    }
  };

  const saveToSupabase = async (parsed: any, barcode: string) => {
    try {
      await supabase.from('scan_history').insert({
        profile_id: null, member_id: null, barcode,
        product_name: parsed.productName || 'Unknown', scan_tab: activeTab,
        verdict_level: parsed.verdictLevel || 'caution', verdict_label: parsed.verdict || '',
        allergen_triggered: (parsed.topAlerts || []).length > 0, allergen_names: parsed.topAlerts || [],
        full_analysis_json: parsed, act_right_earned: 0,
      });
    } catch {}
  };

  const openCamera = async () => {
    if (!permission?.granted) {
      const res = await requestPermission();
      if (!res.granted) { Alert.alert('Camera Permission', 'AA2 needs camera access to scan.'); return; }
    }
    scannedRef.current = false; lastBarcodeRef.current = null; setBarcodeReady(false); setCameraMode(true);
  };

  const handleCapture = async () => {
    if (loading) return;
    const barcode = lastBarcodeRef.current;
    if (activeTab === 'scan') {
      if (barcode) { scannedRef.current = true; setCameraMode(false); await runAnalysis(barcode); }
      else Alert.alert('Point at Barcode', 'Aim at a barcode, then tap capture.');
      return;
    }
    if (activeTab === 'care' && barcode) { scannedRef.current = true; setCameraMode(false); await runAnalysis(barcode); return; }
    setCameraMode(false);
    await runAnalysis(`Vision scan — ${currentTab.label} tab`);
  };

  const handleCancelCamera = () => {
    lastBarcodeRef.current = null; setBarcodeReady(false); scannedRef.current = false; setCameraMode(false);
  };

  const verdictColor = (v: string) => v === 'ALL CLEAR' ? ACCENT.allClear : v === 'HEADS UP' ? ACCENT.headsUp : ACCENT.payAttention;
  const verdictIcon  = (v: string) => v === 'ALL CLEAR' ? '✓' : v === 'HEADS UP' ? '⚠' : '✕';

  // ── TAB BARS ──────────────────────────────────────────────────────────────
  const TopTabBar = () => (
    <View style={[styles.tabGrid, { borderBottomColor: T.border }]}>
      {[TABS.slice(0, 3), TABS.slice(3, 6)].map((row, ri) => (
        <View key={ri} style={styles.tabRow}>
          {row.map(tab => (
            <TouchableOpacity
              key={tab.id}
              style={[styles.tabBtnTop, activeTab === tab.id && { borderBottomColor: tab.color, borderBottomWidth: 2 }]}
              onPress={() => { setActiveTab(tab.id); setResult(null); }}
            >
              <Text style={styles.tabIcon}>{tab.icon}</Text>
              <Text style={[styles.tabLabel, { color: T.textMuted }, activeTab === tab.id && { color: tab.color }]}>{tab.label}</Text>
            </TouchableOpacity>
          ))}
        </View>
      ))}
    </View>
  );

  const LeftTabRail = () => (
    <View style={[styles.leftRail, { backgroundColor: T.railBg, borderRightColor: T.border }]}>
      {TABS.map(tab => (
        <TouchableOpacity
          key={tab.id}
          style={[styles.railBtn, activeTab === tab.id && { borderLeftColor: tab.color, backgroundColor: tab.color + '15' }]}
          onPress={() => { setActiveTab(tab.id); setResult(null); }}
        >
          <Text style={styles.railIcon}>{tab.icon}</Text>
          <Text style={[styles.railLabel, { color: T.textMuted }, activeTab === tab.id && { color: tab.color }]}>{tab.label}</Text>
        </TouchableOpacity>
      ))}
    </View>
  );

  const MainContent = () => (
    <View style={{ flex: 1 }}>
      {/* SPECIES SUB-TABS */}
      {activeTab === 'species' && (
        <View style={styles.speciesRow}>
          {SPECIES_SUBS.map(sub => (
            <TouchableOpacity
              key={sub.id}
              style={[styles.subTab, { borderColor: T.border, backgroundColor: T.card }, speciesSub === sub.id && { backgroundColor: sub.color + '22', borderColor: sub.color }]}
              onPress={() => { setSpeciesSub(sub.id); setResult(null); }}
            >
              <Text style={styles.subTabIcon}>{sub.icon}</Text>
              <Text style={[styles.subTabLabel, { color: T.textMuted }, speciesSub === sub.id && { color: sub.color }]}>{sub.label}</Text>
            </TouchableOpacity>
          ))}
        </View>
      )}

      {/* CAMERA */}
      {cameraMode ? (
        <View style={{ flex: 1 }}>
          <CameraView style={{ flex: 1 }} facing="back"
            onBarcodeScanned={activeTab === 'scan' || activeTab === 'care' ? handleBarcodeScanned : undefined}>
            <View style={styles.cameraOverlay}>
              <View style={styles.cameraFrameGroup}>
                <View style={[styles.scanFrame, { borderColor: accentColor }]} />
                <Text style={[styles.cameraHint, { color: accentColor }]}>
                  {activeTab === 'scan' ? (barcodeReady ? 'BARCODE READY · TAP TO SCAN' : 'POINT AT BARCODE') : 'FRAME THE ITEM'}
                </Text>
              </View>
              <View style={styles.cameraControls}>
                <TouchableOpacity style={[styles.captureCircleOuter, { borderColor: accentColor }]} onPress={handleCapture} activeOpacity={0.85}>
                  <View style={[styles.captureCircleInner, { backgroundColor: accentColor }]} />
                </TouchableOpacity>
                <TouchableOpacity style={[styles.cancelBtn, { backgroundColor: T.card, borderColor: T.border }]} onPress={handleCancelCamera}>
                  <Text style={[styles.cancelBtnText, { color: T.textMuted }]}>✕ CANCEL</Text>
                </TouchableOpacity>
              </View>
            </View>
          </CameraView>
        </View>
      ) : (
        <View style={{ flex: 1 }}>
          {/* BE AWARE GLOW OVERLAY */}
          {showBeAware && (
            <Animated.View style={[
              styles.beAwareOverlay,
              { opacity: beAwareOpacity, transform: [{ scale: beAwareScale }] }
            ]}>
              <Text style={styles.beAwareText}>⚠ BE AWARE</Text>
            </Animated.View>
          )}

          <ScrollView style={{ flex: 1 }} contentContainerStyle={{ paddingBottom: 60 }}>

            {/* DOCTRINE BANNER — borderColor single property ensures all 4 sides */}
            <View style={[
              styles.doctrineBanner,
              {
                backgroundColor: T.card,
                borderColor: accentColor,
              }
            ]}>
              <Text style={[styles.doctrineTitleText, { color: accentColor }]}>
                {activeTab === 'meat'       ? '⚠ CO₂/MAP TRUTH DOCTRINE' :
                 activeTab === 'care'       ? '⚠ SKIN INGESTION DOCTRINE' :
                 activeTab === 'grownfolks' ? '🍷 GROWN FOLKS TABLE' :
                 activeTab === 'species'    ? `${SPECIES_SUBS.find(s => s.id === speciesSub)?.icon} SPECIES INTELLIGENCE` :
                 activeTab === 'produce'    ? '🌿 FRESH PRODUCE INTELLIGENCE' :
                 '⚡ SCAN — SAFETY CLARIFIER ADAPTIVE NERVE'}
              </Text>
              <Text style={[styles.doctrineBody, { color: T.textMuted }]}>
                {activeTab === 'meat'       ? 'CO₂ keeps meat bright red long after it degrades. Your eyes are being deceived. The Equalizer sees through it.' :
                 activeTab === 'care'       ? 'The skin absorbs everything. It is not a barrier — it is an organ. What touches skin enters your bloodstream.' :
                 activeTab === 'grownfolks' ? 'The Sommelier knows the $12 bottle that beats the $90 one. Real knowledge. Real pairings. Grown folks only.' :
                 activeTab === 'species' && speciesSub === 'k9'    ? 'ASPCA Animal Poison Control + canine toxicology. Your animal cannot speak. The Equalizer does.' :
                 activeTab === 'species' && speciesSub === 'horse' ? 'FEI prohibited substances primary. Every ingredient checked for competition readiness.' :
                 activeTab === 'species' && speciesSub === 'agri'  ? 'USDA feed safety + mycotoxin database. Protecting the herd from slow, invisible harm.' :
                 activeTab === 'produce'    ? 'No barcode needed. EWG Dirty Dozen / Clean 15. Pesticide residue likelihood. The Chef on preparation.' :
                 'SCAN — Safety Clarifier Adaptive Nerve'}
              </Text>
            </View>

            {/* SCAN INPUT — collapses when result showing */}
            {result && !loading ? (
              <TouchableOpacity style={[styles.scanAgainBar, { borderColor: accentColor }]} onPress={() => setResult(null)} activeOpacity={0.85}>
                <Text style={[styles.scanAgainBarText, { color: accentColor }]}>
                  {activeTab === 'scan' ? '⚡ SCAN ANOTHER' : '📷 SCAN ANOTHER'}
                </Text>
              </TouchableOpacity>
            ) : !showBeAware ? (
              <View style={[styles.inputCard, { backgroundColor: T.card, borderColor: T.border }]}>
                <TouchableOpacity style={[styles.cameraBtn, { backgroundColor: accentColor + '22', borderColor: accentColor }]} onPress={openCamera}>
                  <Text style={[styles.cameraBtnIcon, { color: accentColor }]}>{activeTab === 'scan' ? '⚡' : '📷'}</Text>
                  <Text style={[styles.cameraBtnLabel, { color: accentColor }]}>{activeTab === 'scan' ? 'SCAN BARCODE' : 'OPEN CAMERA'}</Text>
                </TouchableOpacity>
                <Text style={[styles.orDivider, { color: T.textMuted }]}>— or type it —</Text>
                <TextInput
                  style={[styles.manualInput, { borderColor: accentColor + '55', backgroundColor: T.inputBg, color: T.text }]}
                  placeholder={
                    activeTab === 'scan'       ? 'Product name or barcode number...' :
                    activeTab === 'produce'    ? 'e.g. Strawberries, spinach, apples...' :
                    activeTab === 'meat'       ? 'e.g. Ground beef, chicken breast...' :
                    activeTab === 'care'       ? 'e.g. Dove soap, Neutrogena SPF...' :
                    activeTab === 'grownfolks' ? 'e.g. Malbec, Macallan 12, Guinness...' :
                    speciesSub === 'k9'    ? 'e.g. Blue Buffalo, peanut butter treat...' :
                    speciesSub === 'horse' ? 'e.g. SmartPak supplement, Timothy hay...' :
                    'e.g. Purina cattle feed, corn silage...'
                  }
                  placeholderTextColor={T.textMuted}
                  value={manualInput}
                  onChangeText={setManualInput}
                  onSubmitEditing={handleManualSubmit}
                  returnKeyType="go"
                />
                <TouchableOpacity style={[styles.analyzeBtn, { backgroundColor: accentColor }]} onPress={handleManualSubmit}>
                  <Text style={styles.analyzeBtnText}>RUN ANALYSIS</Text>
                </TouchableOpacity>
              </View>
            ) : null}

            {/* LOADING */}
            {loading && (
              <View style={[styles.loadingCard, { backgroundColor: T.card, borderColor: T.border }]}>
                <ActivityIndicator size="large" color={accentColor} />
                <Text style={[styles.loadingLabel, { color: accentColor }]}>THE EQUALIZER IS RUNNING</Text>
                <Text style={[styles.loadingDb, { color: T.textMuted }]}>9 DATABASES · ALL INTELLIGENCES ACTIVE</Text>
              </View>
            )}

            {/* RESULT */}
            {result && !loading && (
              <View style={styles.resultBlock}>
                <View style={[styles.verdictBanner, { backgroundColor: verdictColor(result.verdict) + '20', borderColor: verdictColor(result.verdict) }]}>
                  <Text style={[styles.verdictIcon, { color: verdictColor(result.verdict) }]}>{verdictIcon(result.verdict)}</Text>
                  <View style={{ flex: 1 }}>
                    <Text style={[styles.verdictText, { color: verdictColor(result.verdict) }]}>{result.verdict}</Text>
                    <Text style={[styles.verdictReason, { color: T.textMuted }]}>{result.verdictReason}</Text>
                  </View>
                </View>

                {result.productName && <Text style={[styles.productName, { color: T.text }]}>{result.productName}</Text>}

                {result.recallAlert && (
                  <View style={styles.recallBanner}>
                    <Text style={styles.recallText}>🚨 RECALL ALERT: {result.recallAlert}</Text>
                  </View>
                )}

                <View style={[styles.intelCard, { backgroundColor: T.card, borderColor: T.border }]}>
                  <Text style={[styles.intelBody, { color: T.text }]}>{result.equalizerVoice}</Text>
                </View>

                {result.keyFindings?.length > 0 && (
                  <View style={[styles.findingsCard, { backgroundColor: T.card, borderColor: T.border }]}>
                    <Text style={[styles.findingsHeader, { color: T.textMuted }]}>KEY FINDINGS</Text>
                    {result.keyFindings.map((f: string, i: number) => (
                      <View key={i} style={styles.findingRow}>
                        <Text style={[styles.findingDot, { color: accentColor }]}>▸</Text>
                        <Text style={[styles.findingText, { color: T.text }]}>{f}</Text>
                      </View>
                    ))}
                  </View>
                )}

                {result.chefNote && (
                  <View style={[styles.intelCard, { backgroundColor: T.card, borderColor: T.border, borderLeftColor: ACCENT.orange }]}>
                    <Text style={[styles.intelHeader, { color: ACCENT.orange }]}>
                      {activeTab === 'care'       ? '⚗ Cosmo Chemist' :
                       activeTab === 'grownfolks' ? '🍷 THE SOMMELIER' :
                       activeTab === 'species'    ? (speciesSub === 'k9' ? '🐕 Canine Nutritionist' : speciesSub === 'horse' ? '🐴 Equine Nutritionist' : '🌾 Agricultural Analyst') :
                       '👨‍🍳 THE CHEF'}
                    </Text>
                    <Text style={[styles.intelBody, { color: T.text }]}>{result.chefNote}</Text>
                  </View>
                )}

                {result.alternatives?.length > 0 && (
                  <View style={[styles.altCard, { backgroundColor: T.card, borderColor: T.border }]}>
                    <Text style={[styles.altHeader, { color: T.textMuted }]}>BETTER ALTERNATIVES</Text>
                    {result.alternatives.map((a: string, i: number) => (
                      <Text key={i} style={[styles.altItem, { color: ACCENT.teal }]}>→ {a}</Text>
                    ))}
                  </View>
                )}

                {result.actRightDollars && (
                  <View style={styles.vaultCard}>
                    <Text style={styles.vaultLabel}>💎 ACT RIGHT DOLLARS</Text>
                    <Text style={[styles.vaultBody, { color: T.text }]}>{result.actRightDollars}</Text>
                  </View>
                )}
              </View>
            )}

            {/* EMPTY STATE — text first, hero image below */}
            {!result && !loading && !showBeAware && (
              <View style={styles.emptyState}>
                <Text style={[styles.emptyIcon, { color: accentColor + '88' }]}>{currentTab.icon}</Text>
                <Text style={[styles.emptyLabel, { color: T.textMuted }]}>READY TO SCAN</Text>
                <Text style={[styles.emptySubLabel, { color: T.textMuted }]}>9 databases standing by</Text>
                {(() => {
                  const imgKey = activeTab === 'species' ? speciesSub : activeTab;
                  const img = TAB_IMAGES[imgKey];
                  return img ? (
                    <Image
                      source={img}
                      style={styles.heroImage}
                      resizeMode="cover"
                    />
                  ) : null;
                })()}
              </View>
            )}

          </ScrollView>
        </View>
      )}
    </View>
  );

  return (
    <SafeAreaView style={[styles.root, { backgroundColor: T.bg }]}>

      {/* HEADER */}
      <View style={[styles.header, { borderBottomColor: T.border }]}>
        <Text style={[styles.receipt, { color: T.textMuted }]} numberOfLines={1}>I AM THE RECEIPT</Text>
        <Text style={styles.logoSymbol}>🧬</Text>
        <TouchableOpacity onPress={() => setHistoryVisible(true)} style={styles.historyBtn}>
          <Text style={[styles.historyBtnText, { color: T.textMuted }]}>{history.length > 0 ? `⏱ ${history.length}` : '⏱'}</Text>
        </TouchableOpacity>
      </View>

      {isFold ? (
        <View style={styles.foldLayout}>
          <LeftTabRail />
          <MainContent />
        </View>
      ) : (
        <View style={{ flex: 1 }}>
          <TopTabBar />
          <MainContent />
        </View>
      )}

      {/* HISTORY MODAL */}
      <Modal visible={historyVisible} animationType="slide" presentationStyle="pageSheet">
        <SafeAreaView style={[styles.modalRoot, { backgroundColor: T.modalBg }]}>
          <View style={[styles.modalHeader, { borderBottomColor: T.border }]}>
            <Text style={[styles.modalTitle, { color: T.text }]}>SCAN HISTORY</Text>
            <TouchableOpacity onPress={() => setHistoryVisible(false)}>
              <Text style={[styles.modalClose, { color: T.textMuted }]}>✕</Text>
            </TouchableOpacity>
          </View>
          {history.length === 0 ? (
            <View style={styles.emptyHistory}><Text style={[styles.emptyHistoryText, { color: T.textMuted }]}>No scans yet</Text></View>
          ) : (
            <FlatList
              data={history}
              keyExtractor={item => item.id}
              contentContainerStyle={{ padding: 16 }}
              renderItem={({ item }) => (
                <View style={[styles.historyRow, { borderBottomColor: T.border }]}>
                  <View style={[styles.historyDot, { backgroundColor: verdictColor(item.verdict) }]} />
                  <View style={{ flex: 1 }}>
                    <Text style={[styles.historyProduct, { color: T.text }]}>{item.productName}</Text>
                    <Text style={[styles.historyMeta, { color: T.textMuted }]}>{item.tab} · {item.timestamp}</Text>
                  </View>
                  <Text style={[styles.historyVerdict, { color: verdictColor(item.verdict) }]}>
                    {item.verdict === 'ALL CLEAR' ? '✓' : item.verdict === 'HEADS UP' ? '⚠' : '✕'}
                  </Text>
                </View>
              )}
            />
          )}
          <TouchableOpacity style={[styles.clearHistoryBtn, { borderColor: ACCENT.red + '66' }]} onPress={() => { setHistory([]); setHistoryVisible(false); }}>
            <Text style={[styles.clearHistoryText, { color: ACCENT.red }]}>CLEAR HISTORY</Text>
          </TouchableOpacity>
        </SafeAreaView>
      </Modal>

    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  root:   { flex: 1 },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 16, paddingTop: 8, paddingBottom: 6, borderBottomWidth: 1 },
  receipt:        { fontFamily: Platform.OS === 'ios' ? 'Courier New' : 'monospace', fontSize: 9, letterSpacing: 2, flex: 1 },
  logoSymbol:     { fontSize: 20, color: ACCENT.electricBlue, flex: 1, textAlign: 'center' },
  historyBtn:     { flex: 1, alignItems: 'flex-end' },
  historyBtnText: { fontSize: 11, fontWeight: '700' },

  // Phone top tabs
  tabGrid:   { borderBottomWidth: 1 },
  tabRow:    { flexDirection: 'row' },
  tabBtnTop: { flex: 1, paddingVertical: 10, alignItems: 'center', borderBottomWidth: 2, borderBottomColor: 'transparent' },
  tabIcon:   { fontSize: 16 },
  tabLabel:  { fontSize: 8, fontWeight: '800', letterSpacing: 0.8, marginTop: 2 },

  // Fold left rail
  foldLayout: { flex: 1, flexDirection: 'row' },
  leftRail:   { width: 80, borderRightWidth: 1, paddingTop: 8 },
  railBtn:    { alignItems: 'center', paddingVertical: 14, paddingHorizontal: 4, borderLeftWidth: 3, borderLeftColor: 'transparent', marginBottom: 2 },
  railIcon:   { fontSize: 20, marginBottom: 4 },
  railLabel:  { fontSize: 7, fontWeight: '800', letterSpacing: 0.5, textAlign: 'center' },

  // Species
  speciesRow:  { flexDirection: 'row', paddingHorizontal: 12, paddingVertical: 8, gap: 8 },
  subTab:      { flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 4, paddingVertical: 8, borderRadius: 8, borderWidth: 1 },
  subTabIcon:  { fontSize: 14 },
  subTabLabel: { fontSize: 9, fontWeight: '800', letterSpacing: 0.5 },

  // BE AWARE overlay
  beAwareOverlay: {
    position: 'absolute', top: 0, left: 0, right: 0, bottom: 0,
    zIndex: 100, justifyContent: 'center', alignItems: 'center',
    backgroundColor: 'rgba(224,82,82,0.15)',
  },
  beAwareText: {
    fontSize: 32, fontWeight: '900', color: '#e05252',
    letterSpacing: 4,
    textShadowColor: 'rgba(224,82,82,0.8)',
    textShadowOffset: { width: 0, height: 0 },
    textShadowRadius: 20,
  },

  // Doctrine banner — borderWidth set here, borderColor set inline
  doctrineBanner:    { marginHorizontal: 12, marginTop: 10, padding: 12, borderRadius: 10, borderWidth: 2 },
  doctrineTitleText: { fontSize: 10, fontWeight: '800', letterSpacing: 1.5, marginBottom: 4 },
  doctrineBody:      { fontSize: 11, lineHeight: 17 },

  // Scan input
  scanAgainBar:    { marginHorizontal: 12, marginTop: 10, marginBottom: 4, paddingVertical: 12, borderRadius: 8, borderWidth: 1.5, alignItems: 'center' },
  scanAgainBarText:{ fontWeight: '900', fontSize: 12, letterSpacing: 1.5 },
  inputCard:       { margin: 12, padding: 16, borderRadius: 12, borderWidth: 1 },
  cameraBtn:       { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 10, padding: 14, borderRadius: 10, borderWidth: 1, marginBottom: 12 },
  cameraBtnIcon:   { fontSize: 20 },
  cameraBtnLabel:  { fontWeight: '900', fontSize: 13, letterSpacing: 1.5 },
  orDivider:       { fontSize: 10, textAlign: 'center', marginBottom: 10, letterSpacing: 2 },
  manualInput:     { borderWidth: 1, borderRadius: 8, padding: 12, fontSize: 13, marginBottom: 10 },
  analyzeBtn:      { paddingVertical: 13, borderRadius: 8, alignItems: 'center' },
  analyzeBtnText:  { color: '#03050a', fontWeight: '900', fontSize: 12, letterSpacing: 1.5 },

  // Camera
  cameraOverlay:      { flex: 1, backgroundColor: 'rgba(0,0,0,0.4)', justifyContent: 'space-between', alignItems: 'center', paddingTop: 40, paddingBottom: 48 },
  cameraFrameGroup:   { alignItems: 'center' },
  scanFrame:          { width: 240, height: 160, borderWidth: 2, borderRadius: 12, marginBottom: 20 },
  cameraHint:         { fontWeight: '800', fontSize: 12, letterSpacing: 2 },
  cameraControls:     { alignItems: 'center', width: '100%' },
  captureCircleOuter: { width: 80, height: 80, borderRadius: 40, borderWidth: 4, alignItems: 'center', justifyContent: 'center', marginBottom: 20 },
  captureCircleInner: { width: 60, height: 60, borderRadius: 30 },
  cancelBtn:          { paddingVertical: 12, paddingHorizontal: 28, borderRadius: 10, borderWidth: 1 },
  cancelBtnText:      { fontSize: 12, fontWeight: '800', letterSpacing: 1.5 },

  // Loading
  loadingCard:  { margin: 12, padding: 28, borderRadius: 12, alignItems: 'center', borderWidth: 1 },
  loadingLabel: { fontWeight: '900', fontSize: 11, letterSpacing: 2, marginTop: 14 },
  loadingDb:    { fontSize: 9, letterSpacing: 1.5, marginTop: 6 },

  // Result
  resultBlock:   { margin: 12 },
  verdictBanner: { flexDirection: 'row', alignItems: 'center', gap: 12, padding: 16, borderRadius: 12, borderWidth: 2, marginBottom: 10 },
  verdictIcon:   { fontSize: 28, fontWeight: '900', width: 36, textAlign: 'center' },
  verdictText:   { fontSize: 18, fontWeight: '900', letterSpacing: 1 },
  verdictReason: { fontSize: 12, marginTop: 2, lineHeight: 18 },
  productName:   { fontSize: 15, fontWeight: '700', marginBottom: 10, paddingHorizontal: 4 },
  recallBanner:  { backgroundColor: 'rgba(224,82,82,0.2)', borderRadius: 8, borderWidth: 1, borderColor: ACCENT.red, padding: 10, marginBottom: 10 },
  recallText:    { color: ACCENT.red, fontWeight: '800', fontSize: 12 },
  intelCard:     { borderRadius: 10, borderLeftWidth: 3, borderLeftColor: ACCENT.electricBlue, borderWidth: 1, padding: 14, marginBottom: 10 },
  intelHeader:   { color: ACCENT.electricBlue, fontSize: 9, fontWeight: '900', letterSpacing: 2, marginBottom: 8 },
  intelBody:     { fontSize: 13, lineHeight: 21 },
  findingsCard:  { borderRadius: 10, borderWidth: 1, padding: 14, marginBottom: 10 },
  findingsHeader:{ fontSize: 9, fontWeight: '900', letterSpacing: 2, marginBottom: 10 },
  findingRow:    { flexDirection: 'row', gap: 8, marginBottom: 8 },
  findingDot:    { fontSize: 11, marginTop: 2 },
  findingText:   { fontSize: 12, lineHeight: 19, flex: 1 },
  altCard:       { borderRadius: 10, borderWidth: 1, padding: 14, marginBottom: 10 },
  altHeader:     { fontSize: 9, fontWeight: '900', letterSpacing: 2, marginBottom: 8 },
  altItem:       { fontSize: 13, lineHeight: 22 },
  vaultCard:     { backgroundColor: 'rgba(201,168,76,0.12)', borderRadius: 10, borderWidth: 1, borderColor: ACCENT.gold, padding: 14, marginBottom: 10 },
  vaultLabel:    { color: ACCENT.gold, fontSize: 9, fontWeight: '900', letterSpacing: 2, marginBottom: 6 },
  vaultBody:     { fontSize: 13, lineHeight: 20 },

  // Empty
  emptyState:    { alignItems: 'center', paddingTop: 30, paddingBottom: 20, paddingHorizontal: 12 },
  heroImage:     { width: '100%', height: 200, borderRadius: 14, marginTop: 16 },
  emptyIcon:     { fontSize: 48 },
  emptyLabel:    { fontWeight: '900', fontSize: 11, letterSpacing: 3, marginTop: 16 },
  emptySubLabel: { fontSize: 9, letterSpacing: 2, marginTop: 4 },

  // Modal
  modalRoot:        { flex: 1 },
  modalHeader:      { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', padding: 16, borderBottomWidth: 1 },
  modalTitle:       { fontWeight: '900', fontSize: 14, letterSpacing: 2 },
  modalClose:       { fontSize: 18, fontWeight: '700' },
  emptyHistory:     { flex: 1, alignItems: 'center', justifyContent: 'center' },
  emptyHistoryText: { fontSize: 13 },
  historyRow:       { flexDirection: 'row', alignItems: 'center', gap: 12, paddingVertical: 12, borderBottomWidth: 1 },
  historyDot:       { width: 10, height: 10, borderRadius: 5 },
  historyProduct:   { fontSize: 13, fontWeight: '700' },
  historyMeta:      { fontSize: 10, marginTop: 2 },
  historyVerdict:   { fontSize: 18, fontWeight: '900' },
  clearHistoryBtn:  { margin: 16, padding: 14, borderRadius: 8, borderWidth: 1, alignItems: 'center' },
  clearHistoryText: { fontWeight: '800', fontSize: 11, letterSpacing: 1.5 },
});
