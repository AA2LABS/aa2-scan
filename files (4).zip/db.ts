/**
 * AA2 DATABASE ABSTRACTION LAYER
 * lib/db.ts
 *
 * SOVEREIGNTY DOCTRINE:
 * The app never calls Supabase directly. Everything goes through here.
 * When AA2 exits Supabase — change this file only. Nothing else changes.
 * The membrane never knows what's behind the curtain.
 *
 * Sealed: Canon v25
 */

import { supabase } from './supabase';

// ─── TYPES ────────────────────────────────────────────────────────────────────

export type MemberProfile = {
  member_id: string;
  name: string | null;
  age: string | null;
  species_protected: string[];
  delivery_mode: string;
  color_mode: string;
  onboarding_complete: boolean;
};

export type GoalProfile = {
  member_id: string;
  primary_goal: string[];
  vision_text: string | null;
};

export type AllergyProfile = {
  member_id: string;
  food_allergens: string[];
  suspected_sensitivities: string[];
  personal_care_allergens: string[];
  environmental_triggers: string[];
};

export type HealthProfile = {
  member_id: string;
  conditions: string[];
  active_limits: string[];
  medications: string | null;
  diet_types: string[];
};

export type BaselineProfile = {
  member_id: string;
  sleep_score: number | null;
  stress_level: string | null;
};

export type TravelProfile = {
  member_id: string;
  travel_frequency: string[];
};

export type MemberContext = {
  member: MemberProfile | null;
  goals: GoalProfile | null;
  allergies: AllergyProfile | null;
  health: HealthProfile | null;
  baseline: BaselineProfile | null;
  travel: TravelProfile | null;
};

// ─── MEMBER CONTEXT — pulls everything needed for personal truth ──────────────

export async function getMemberContext(memberId: string): Promise<MemberContext> {
  try {
    const [
      memberRes,
      goalsRes,
      allergyRes,
      healthRes,
      baselineRes,
      travelRes,
    ] = await Promise.all([
      supabase.from('member_profiles').select('*').eq('member_id', memberId).single(),
      supabase.from('goal_profiles').select('*').eq('member_id', memberId).single(),
      supabase.from('allergy_profiles').select('*').eq('member_id', memberId).single(),
      supabase.from('health_profiles').select('*').eq('member_id', memberId).single(),
      supabase.from('baseline_profiles').select('*').eq('member_id', memberId).single(),
      supabase.from('travel_profiles').select('*').eq('member_id', memberId).single(),
    ]);

    return {
      member:   memberRes.data   ?? null,
      goals:    goalsRes.data    ?? null,
      allergies: allergyRes.data ?? null,
      health:   healthRes.data   ?? null,
      baseline: baselineRes.data ?? null,
      travel:   travelRes.data   ?? null,
    };
  } catch {
    // Fail gracefully — return null context, scanner returns generic truth
    return {
      member: null, goals: null, allergies: null,
      health: null, baseline: null, travel: null,
    };
  }
}

// ─── CURRENT USER ────────────────────────────────────────────────────────────

export async function getCurrentMemberId(): Promise<string | null> {
  try {
    const { data: { user } } = await supabase.auth.getUser();
    return user?.id ?? null;
  } catch {
    return null;
  }
}

// ─── SCAN HISTORY ────────────────────────────────────────────────────────────

export async function saveScanRecord(params: {
  memberId: string | null;
  barcode: string;
  productName: string;
  scanTab: string;
  verdictLevel: string;
  verdictLabel: string;
  allergenTriggered: boolean;
  allergenNames: string[];
  fullAnalysisJson: any;
  actRightEarned: number;
}): Promise<void> {
  try {
    await supabase.from('scan_history').insert({
      profile_id:        null,
      member_id:         params.memberId,
      barcode:           params.barcode,
      product_name:      params.productName,
      scan_tab:          params.scanTab,
      verdict_level:     params.verdictLevel,
      verdict_label:     params.verdictLabel,
      allergen_triggered: params.allergenTriggered,
      allergen_names:    params.allergenNames,
      full_analysis_json: params.fullAnalysisJson,
      act_right_earned:  params.actRightEarned,
    });
  } catch {
    // Silent fail — never surface database errors to the member
  }
}

// ─── PERSONAL TRUTH BUILDER ──────────────────────────────────────────────────
/**
 * Takes member context and builds the personal truth injection
 * that gets prepended to every system prompt.
 *
 * Without onboarding: returns empty string → generic truth
 * With onboarding: returns full context → personal truth
 *
 * THE DONUT KNOWS ABOUT THE BIKINI BECAUSE OF THIS FUNCTION.
 */

export function buildPersonalTruth(context: MemberContext): string {
  if (!context.member || !context.member.onboarding_complete) {
    return ''; // No initiation = generic truth only
  }

  const lines: string[] = [];

  // Member identity
  if (context.member.name) {
    lines.push(`MEMBER NAME: ${context.member.name}`);
  }

  // Declared goals — this is where the bikini lives
  if (context.goals) {
    if (context.goals.primary_goal?.length > 0) {
      lines.push(`DECLARED GOALS: ${context.goals.primary_goal.join(', ')}`);
    }
    if (context.goals.vision_text) {
      lines.push(`VISION: ${context.goals.vision_text}`);
    }
  }

  // Active health limits — permanent filters on every scan
  if (context.health) {
    if (context.health.active_limits?.length > 0) {
      lines.push(`ACTIVE LIMITS (permanent scan filter): ${context.health.active_limits.join(', ')}`);
    }
    if (context.health.conditions?.length > 0) {
      lines.push(`HEALTH CONDITIONS: ${context.health.conditions.join(', ')}`);
    }
    if (context.health.diet_types?.length > 0) {
      lines.push(`DIET: ${context.health.diet_types.join(', ')}`);
    }
    if (context.health.medications) {
      lines.push(`MEDICATIONS/SUPPLEMENTS: ${context.health.medications}`);
    }
  }

  // Allergens — life-safety layer
  if (context.allergies) {
    if (context.allergies.food_allergens?.length > 0) {
      lines.push(`KNOWN FOOD ALLERGENS (LIFE SAFETY): ${context.allergies.food_allergens.join(', ')}`);
    }
    if (context.allergies.suspected_sensitivities?.length > 0) {
      lines.push(`SUSPECTED SENSITIVITIES: ${context.allergies.suspected_sensitivities.join(', ')}`);
    }
    if (context.allergies.personal_care_allergens?.length > 0) {
      lines.push(`PERSONAL CARE ALLERGENS: ${context.allergies.personal_care_allergens.join(', ')}`);
    }
    if (context.allergies.environmental_triggers?.length > 0) {
      lines.push(`ENVIRONMENTAL TRIGGERS: ${context.allergies.environmental_triggers.join(', ')}`);
    }
  }

  // Baseline — context for biosignal cross-reference
  if (context.baseline) {
    if (context.baseline.sleep_score !== null) {
      const sleepLabels = ['', 'Restless', 'Light', 'Inconsistent', 'Mostly Solid', 'Deep'];
      lines.push(`SLEEP BASELINE: ${sleepLabels[context.baseline.sleep_score] ?? context.baseline.sleep_score}`);
    }
    if (context.baseline.stress_level) {
      lines.push(`STRESS BASELINE: ${context.baseline.stress_level}`);
    }
  }

  // Travel context
  if (context.travel?.travel_frequency?.length > 0) {
    lines.push(`TRAVEL PROFILE: ${context.travel.travel_frequency.join(', ')}`);
  }

  if (lines.length === 0) return '';

  return `
PERSONAL TRUTH CONTEXT — THIS MEMBER HAS COMPLETED INITIATION:
${lines.join('\n')}

CRITICAL INSTRUCTIONS FOR PERSONAL TRUTH MODE:
- Address this member by name if provided
- Cross-reference EVERY scan result against their declared goals
- If this product conflicts with their goals, say so directly but with warmth — like their most honest, loving friend
- If they have declared active limits (sodium, sugar, etc.) flag any violation immediately — this is a permanent filter
- If any KNOWN FOOD ALLERGEN is present — this is LIFE SAFETY — flag it first, above everything else
- Speak to where they said they are going, not just what they scanned
- The system knows their vision. Every scan is measured against it.
- Example tone: "That's not going to get you to [their goal], [name]. Here's what will."
- Never preachy. Never shaming. Honest. Warm. Invested in their declared future.
`.trim();
}
